<?php
return array(
	//'配置项'=>'配置值'
	'APPID' => 'wxdb39708ea70f0e42',
	'AppSecret' => '04ef4ebbe67d1e36ee3154ca2543b76b',
);