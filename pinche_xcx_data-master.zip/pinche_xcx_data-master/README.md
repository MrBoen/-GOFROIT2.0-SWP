# pinche_xcx_data

[![GitHub stars](https://img.shields.io/github/stars/vincenth520/pinche_xcx_data.svg)](https://github.com/vincenth520/pinche_xcx_data/stargazers)
[![GitHub forks](https://img.shields.io/github/forks/vincenth520/pinche_xcx_data.svg)](https://github.com/vincenth520/pinche_xcx_data/network)
[![GitHub issues](https://img.shields.io/github/issues/vincenth520/pinche_xcx_data.svg)](https://github.com/vincenth520/pinche_xcx_data/issues)
[![GitHub release](https://img.shields.io/github/release/vincenth520/pinche_xcx_data.svg)](https://github.com/vincenth520/pinche_xcx_data/releases)
[![GitHub license](https://img.shields.io/badge/license-APACHE2.0-blue.svg)](https://raw.githubusercontent.com/vincenth520/pinche_xcx_data/master/LICENSE)

## 项目说明

此源码为同城拼车微信小程序的后端源码，此源码只用作学习和交流,请勿用作商业用途及销售获利


- 前端代码地址：[https://github.com/vincenth520/pinche_xcx](https://github.com/vincenth520/pinche_xcx)
- 后端代码地址：[https://github.com/vincenth520/pinche_xcx_data](https://github.com/vincenth520/pinche_xcx_data)


## 关于如何配置

[点击查看配置教程](https://github.com/vincenth520/pinche_xcx_data/wiki/%E5%85%B3%E4%BA%8E%E9%85%8D%E7%BD%AE%E5%90%8C%E5%9F%8E%E6%8B%BC%E8%BD%A6%E5%BE%AE%E4%BF%A1%E5%B0%8F%E7%A8%8B%E5%BA%8F%E5%90%8E%E7%AB%AF)



## 有问题
你可以用以下联系方式找到我(`不接受问问题,有问题请直接提交`[issue](https://github.com/vincenth520/pinche_xcx/issues))

(点击链接加入群【微信小程序开发交流】：https://jq.qq.com/?_wv=1027&k=4Em0dwJ)

- email[[1091986039@qq.com](mailto:1091986039@qq.com)]
- qq[1091986039]
- wechat[1091986039]